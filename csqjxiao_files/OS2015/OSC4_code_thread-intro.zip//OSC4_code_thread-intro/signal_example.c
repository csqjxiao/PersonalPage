#define SIGHUP  1   /* Hang up the process */ 
#define SIGINT  2   /* Interrupt the process */ 
#define SIGQUIT 3   /* Quit the process */ 
#define SIGILL  4   /* Illegal instruction. */ 
#define SIGTRAP 5   /* Trace trap. */ 
#define SIGABRT 6   /* Abort. */

// C program to illustrate
// User-defined Signal Handler
#include <stdio.h>
#include <signal.h>

// Handler for SIGINT, triggered by
// Ctrl-C at the keyboard
void handle_sigint(int sig)  {
    printf("Caught signal %d\n", sig);
}

int main()  {
    signal(SIGINT, handle_sigint);
    for (int i=0; 1; i++) {
        printf("hello world %d\n", i);
	sleep(1);
    }
    return 0;
}

