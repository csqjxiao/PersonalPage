#include <pthread.h>
#include <stdio.h>

int value = 0;  
void *runner(void *param){
   value = value + 10;
   pthread_exit(0);
}

int main(int argc, char *argv[])
{   
    int  pid;
    pthread_t  tid;
    pid = fork();
    if (pid == 0) { 
        pthread_create (&tid, NULL, runner, NULL);
        pthread_join (tid, NULL);
        printf ("CHILD: value = %d\n", value);  /*Print 1*/
    } else if (pid > 0) {
	value = value - 10;
        wait(NULL);
        printf("PARENT: value = %d\n", value);  /*Print 2*/
    }
}
