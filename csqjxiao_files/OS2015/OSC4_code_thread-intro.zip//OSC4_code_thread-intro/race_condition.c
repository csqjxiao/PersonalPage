#include <stdio.h>
#include <pthread.h>


void * helloFunc ( void * ptr ) {
    int *data;            
    data = (int *) ptr;    
    printf("I’m Thread %d \n", *data);    
}

int main() {
    pthread_t hThread[4];  
    int thread_name[4];

    for (int i = 0; i < 4; i++) {
	thread_name[i] = i;
        pthread_create(&hThread[i], NULL, helloFunc, (void *)&thread_name[i]);
    }
    for (int i = 0; i < 4; i++)
        pthread_join(hThread[i], NULL);
    return 0;
}

