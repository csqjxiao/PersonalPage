#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {
	ssize_t len;
	char * filename;
	int key;

	if(argc != 2) {
		fprintf(stderr, "invalid parameters! should be filename.\n");
		return EXIT_FAILURE;
	}
	fprintf(stdout, "file format: key(integer) + value(integer)\n");
	fprintf(stdout, "size of an integer is %d\n", sizeof(int));

	filename = argv[1];
	int fd = open(filename, O_WRONLY | O_CREAT | O_EXCL,
		    S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
	for(key = 1; key < 100; key++) {
		write(fd, &key, sizeof(int));
		write(fd, &key, sizeof(int)); // value = key
	}
	close(fd);
}
