#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>

void memshuffle(void * buf, int len, int card_size);
void memswap(void * buf, int len, int pos1, int pos2);

int main(int argc, char *argv[]) {
	ssize_t len;
	char * filename;
	int card_size, fd;
	void * buf;

	if(argc != 3) {
		fprintf(stderr, "invalid parameters! should be filename + card_size.\n");
		return EXIT_FAILURE;
	}

	filename = argv[1];
	card_size = strtol(argv[2], NULL, 10);

	fd = open(filename, O_RDWR);
	len = lseek(fd, 0, SEEK_END);
	lseek(fd, 0, SEEK_SET);
	buf = mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_FILE | MAP_SHARED, fd, 0);
	if( buf == (void*) -1) {
		fprintf(stderr, "mmap failed.\n");
		exit(EXIT_FAILURE);
	}

	memshuffle(buf, len, card_size);

	munmap(buf, len);
	close(fd);
	return EXIT_SUCCESS;
}


void memshuffle(void * buf, int len, int card_size) {
	int card_num = len / card_size;

	memswap(buf, card_size, 0, len - card_size);
}

void memswap(void * buf, int len, int pos1, int pos2) {
	unsigned char tmp;
	int i;
	for(i=0; i<len; i++) {
		tmp = *((char*)buf+pos1+i);
		*((char*)buf+pos1+i) = *((char*)buf+pos2+i);
		*((char*)buf+pos2+i) = tmp;
	}
}
