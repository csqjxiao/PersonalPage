#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {
	ssize_t len;
	char * filename;
	int key, val;

	if(argc != 2) {
		fprintf(stderr, "invalid parameters! should be filename.\n");
		return EXIT_FAILURE;
	}

	filename = argv[1];
	int fd = open(filename, O_CREAT);
	while(sizeof(int) == read(fd, &key, sizeof(int))) {
		read(fd, &val, sizeof(int));
		fprintf(stdout, "key %d has a value %d\n", key, val);
	}

	close(fd);
}
