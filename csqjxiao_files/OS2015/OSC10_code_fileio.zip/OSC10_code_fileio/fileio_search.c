#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {
	ssize_t len;
	char * filename;
	int key, srch_key, new_value;

	if(argc != 4) {
		fprintf(stderr, "invalid parameters! should be filename + search key + new value.\n");
		return EXIT_FAILURE;
	}

	filename = argv[1];
	srch_key = strtol(argv[2], NULL, 10);
	new_value = strtol(argv[3], NULL, 10);

	int fd = open(filename, O_RDWR);
	while(sizeof(int) == read(fd, &key, sizeof(int))) {
		if(key != srch_key)
			lseek(fd, sizeof(int), SEEK_CUR);
		else {
			write(fd, &new_value, sizeof(int));
			close(fd);
			fprintf(stdout, "key %d has a new value %d.\n", key, new_value);
			return EXIT_SUCCESS;
		}
	}

	fprintf(stderr, "key not found!\n");
	return EXIT_FAILURE;
}
