#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int
main(int argc, char *argv[])
{
    printf("hello world 1 (pid:%d)\n", (int) getpid());
	int rc = fork();
    printf("hello world 2 (pid:%d)\n", (int) getpid());
    if (rc < 0) {
        // fork failed; exit
        fprintf(stderr, "fork failed\n");
        exit(1);
    } else if (rc == 0) {
        // child (new process)
        sleep(1);
        printf("hello, I am child (pid:%d)\n", (int) getpid());
        return 7;
        exit(-1);
    } else {
    	int status = 0;
        // parent goes down this path (original process)
        int wc = 0;
        wc = wait(&status);
        printf("hello, I am parent of %d (wc:%d, status:%d) (pid:%d)\n",
	       rc, wc, WEXITSTATUS(status), (int) getpid());
    }
    return 0;
}
