/*
 * fork_quiz.c
 *
 *  Created on: Mar 13, 2017
 *      Author: csqjxiao
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int
main(int argc, char *argv[])
{
    int i, id1, id2, id3;
    for (i=0; i<2; i++) {
    	id1 = fork();
    	id2 = fork();
        if (id1 == 0 || id2 == 0) id3 = fork(); else id3 = 0;
//        printf("I am %d, and I have children %d, %d, %d\n", getpid(), id1, id2, id3);
    }
    printf("I am %d, my parent proc is %d\n", getpid(), getppid());
    return 0;
}
