#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int
main(int argc, char *argv[])
{
    int i, id1, id2;
    for (i=1; i<2; i++) {
    	id1 = fork(); wait(NULL);
    	id2 = fork(); wait(NULL);
        if (id1 == 0 || id2 == 0) {
        	fork();
        	wait(NULL);
        }
    }
    printf("I am %d, my parent proc is %d\n", getpid(), getppid());
    return 0;
}
