#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


int main() {
	pid_t pid;
	int cnt = 3;
	pid = vfork();
	if(pid<0)
		printf("error in fork!\n");
	else if(pid == 0 ) {
		cnt ++;
		printf("Child process %d, ", getpid());
		printf("cnt=%d\n", cnt);
//		 exit(0);
	} else {
		cnt ++;
		printf("Parent process %d, ", getpid());
		printf("cnt=%d\n", cnt);
	}
}
