#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

#define N 5  // Number of philosophers

enum { THINKING, HUNGRY, EATING };

typedef struct {
    int state[N];
    pthread_mutex_t mutex;
    pthread_cond_t self[N];
} DiningTable;

DiningTable table;

// Helper: get left and right philosopher index
int left(int i)  { return (i + N - 1) % N; }
int right(int i) { return (i + 1) % N; }

void test(int i) {
    if (table.state[i] == HUNGRY &&
        table.state[left(i)] != EATING &&
        table.state[right(i)] != EATING) {
        table.state[i] = EATING;
        pthread_cond_signal(&table.self[i]);
    }
}

void pickup(int i) {
    pthread_mutex_lock(&table.mutex);
    table.state[i] = HUNGRY;
    test(i);
    while (table.state[i] != EATING) {
	printf("Philosopher %d is hungry.\n", i);
        pthread_cond_wait(&table.self[i], &table.mutex);
    }
    pthread_mutex_unlock(&table.mutex);
}

void putdown(int i) {
    pthread_mutex_lock(&table.mutex);
    table.state[i] = THINKING;
    test(left(i));
    test(right(i));
    pthread_mutex_unlock(&table.mutex);
}

void* philosopher(void* arg) {
    int i = *(int*)arg;
    while (1) {
        printf("Philosopher %d is thinking.\n", i);
        sleep(1);

        pickup(i);
        printf("Philosopher %d is eating.\n", i);
        sleep(2);

        putdown(i);
    }
    return NULL;
}

int main() {
    pthread_t threads[N];
    int ids[N];

    // Initialize table
    pthread_mutex_init(&table.mutex, NULL);
    for (int i = 0; i < N; i++) {
        table.state[i] = THINKING;
        pthread_cond_init(&table.self[i], NULL);
    }

    // Create philosopher threads
    for (int i = 0; i < N; i++) {
        ids[i] = i;
        pthread_create(&threads[i], NULL, philosopher, &ids[i]);
    }

    // Join threads (this program runs infinitely)
    for (int i = 0; i < N; i++) {
        pthread_join(threads[i], NULL);
    }

    return 0;
}


