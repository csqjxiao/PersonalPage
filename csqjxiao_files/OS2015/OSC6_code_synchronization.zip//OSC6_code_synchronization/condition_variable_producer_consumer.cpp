#include <iostream>
#include <pthread.h>
#include <queue>
#include <unistd.h>

class ThreadSafeQueue {
 private:
  std::queue<int> buffer;
  const unsigned int maxSize;
  pthread_mutex_t mtx;
  pthread_cond_t notFull;
  pthread_cond_t notEmpty;

 public:
  explicit ThreadSafeQueue(unsigned int size) : maxSize(size) {
    pthread_mutex_init(&mtx, nullptr);
    pthread_cond_init(&notFull, nullptr);
    pthread_cond_init(&notEmpty, nullptr);
  }

  ~ThreadSafeQueue() {
    pthread_mutex_destroy(&mtx);
    pthread_cond_destroy(&notFull);
    pthread_cond_destroy(&notEmpty);
  }

  void produce(int item) {
    pthread_mutex_lock(&mtx);
    // Wait until the queue is not full
    while (buffer.size() >= maxSize) {
      pthread_cond_wait(&notFull, &mtx);
    }

    buffer.push(item);
    std::cout << "生产: " << item << " (缓冲区大小: " << buffer.size() << ")"
              << std::endl;

    // Notify one consumer
    pthread_cond_signal(&notEmpty);
    pthread_mutex_unlock(&mtx);
  }

  int consume() {
    pthread_mutex_lock(&mtx);
    // Wait until the queue is not empty
    while (buffer.empty()) {
      pthread_cond_wait(&notEmpty, &mtx);
    }

    int item = buffer.front();
    buffer.pop();
    std::cout << "消费: " << item << " (缓冲区大小: " << buffer.size() << ")"
              << std::endl;

    // Notify one producer
    pthread_cond_signal(&notFull);
    pthread_mutex_unlock(&mtx);

    return item;
  }
};

void* producer(void* arg) {
  ThreadSafeQueue* queue = static_cast<ThreadSafeQueue*>(arg);
  for (int i = 0; i < 10; ++i) {
    queue->produce(i);
    usleep(100000);  // Sleep for 100 milliseconds
  }
  return nullptr;
}

void* consumer(void* arg) {
  ThreadSafeQueue* queue = static_cast<ThreadSafeQueue*>(arg);
  for (int i = 0; i < 10; ++i) {
    queue->consume();
    usleep(150000);  // Sleep for 150 milliseconds
  }
  return nullptr;
}

int main() {
  ThreadSafeQueue queue(3);

  pthread_t producerThread, consumerThread;

  // Create producer and consumer threads
  pthread_create(&producerThread, nullptr, producer, &queue);
  pthread_create(&consumerThread, nullptr, consumer, &queue);

  // Wait for both threads to finish
  pthread_join(producerThread, nullptr);
  pthread_join(consumerThread, nullptr);

  return 0;
}

