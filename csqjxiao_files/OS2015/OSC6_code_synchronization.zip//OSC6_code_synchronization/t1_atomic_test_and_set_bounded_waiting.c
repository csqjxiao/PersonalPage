#include <stdio.h>
#include "mythreads.h"
#include <stdlib.h>
#include <pthread.h>

int max;
volatile int counter = 0; // shared global variable
volatile char lock = 0;
#define NUM_OF_WORKERS (2)
volatile char waiting[NUM_OF_WORKERS];

void *
mythread(void *arg)
{
  	int id = * (int*)arg ;

    enum { SEQ_CST = __ATOMIC_SEQ_CST };

    int i; // stack (private per thread) 
    printf("thread %d: begin [addr of i: %p]\n", id, &i);
    for (i = 0; i < max; i++) {
        char key;
        // lock
        waiting[id] = 1;
        __sync_synchronize(); // This builtin issues a full memory barrier.
        key = 1;
        while(waiting[id] && key)
            key=__atomic_test_and_set(&lock, SEQ_CST);
        __sync_synchronize(); // This builtin issues a full memory barrier.
        waiting[id] = 0;
        __sync_synchronize(); // This builtin issues a full memory barrier.

        // critical section
    	counter = counter + 1; // shared: only one

        // unlock
        int j; 
        for(j=(id+1) % NUM_OF_WORKERS; 
            (j!=id) && !waiting[j]; 
            j=(j+1)%NUM_OF_WORKERS) ;
        if(j == id)
            lock = 0;
        else
            waiting[j] = 0;
    }
    printf("thread %d: done\n", id);
    return NULL;
}
                                                                             
int
main(int argc, char *argv[])
{                    
    if (argc != 2) {
	fprintf(stderr, "usage: main-first <loopcount>\n");
	exit(1);
    }
    max = atoi(argv[1]);

    pthread_t p[2];
    int id[2] = {0, 1};

    time_t curr_time = time(NULL);
    printf("main: current time %s", asctime(gmtime(&curr_time)));
    printf("main: begin [counter = %d] [address of counter: %x] \n",
    		counter, (unsigned int) &counter);
    Pthread_create(&p[0], NULL, mythread, &id[0]);
    Pthread_create(&p[1], NULL, mythread, &id[1]);
    // join waits for the threads to finish
    Pthread_join(p[0], NULL);
    Pthread_join(p[1], NULL);
    printf("main: done\n [counter: %d]\n [should: %d]\n", 
	   counter, max*2);

    curr_time = time(NULL);
    printf("main: current time %s", asctime(gmtime(&curr_time)));
    return 0;
}

