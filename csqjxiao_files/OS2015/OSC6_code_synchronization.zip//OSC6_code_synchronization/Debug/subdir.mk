################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../barrier.c \
../t1_mutex.c \
../t1_semaphore.c 

OBJS += \
./barrier.o \
./t1_mutex.o \
./t1_semaphore.o 

C_DEPS += \
./barrier.d \
./t1_mutex.d \
./t1_semaphore.d 


# Each subdirectory must supply rules for building sources it contributes
%.o: ../%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Cross GCC Compiler'
	gcc -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


