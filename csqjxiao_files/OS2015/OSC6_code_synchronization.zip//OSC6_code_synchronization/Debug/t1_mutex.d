t1_mutex.o: ../t1_mutex.c ../mythreads.h

../mythreads.h:
