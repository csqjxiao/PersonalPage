t1_semaphore.o: ../t1_semaphore.c ../mythreads.h

../mythreads.h:
