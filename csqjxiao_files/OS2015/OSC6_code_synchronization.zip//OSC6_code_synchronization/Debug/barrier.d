barrier.o: ../barrier.c
