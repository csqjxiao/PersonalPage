#include <stdio.h>
#include "mythreads.h"
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

int max;
volatile int counter = 0; // shared global variable

sem_t * lock;

void *
mythread(void *arg)
{
    char *letter = arg;
    int i; // stack (private per thread) 
    printf("%s: begin [addr of i: %p]\n", letter, &i);
    for (i = 0; i < max; i++) {
    	sem_wait(lock);
    	counter = counter + 1; // shared: only one
    	sem_post(lock);
    }
    printf("%s: done\n", letter);
    return NULL;
}
                                                                             
int
main(int argc, char *argv[])
{                    
    if (argc != 2) {
	fprintf(stderr, "usage: main-first <loopcount>\n");
	exit(1);
    }
    max = atoi(argv[1]);

    time_t curr_time = time(NULL);
    printf("main: current time %s", asctime(gmtime(&curr_time)));

//    sem_init(&mutex, 0, 1); // sem_init is deprecated on Mac OS
    lock = sem_open("/mysem", O_CREAT, S_IRUSR | S_IWUSR, 1);

    pthread_t p1, p2;
    printf("main: begin [counter = %d] [%x]\n", counter,
	   (unsigned int) &counter);
    Pthread_create(&p1, NULL, mythread, "A"); 
    Pthread_create(&p2, NULL, mythread, "B");
    // join waits for the threads to finish
    Pthread_join(p1, NULL); 
    Pthread_join(p2, NULL); 
    printf("main: done\n [counter: %d]\n [should: %d]\n", 
	   counter, max*2);

//    sem_destroy(mutex); // sem_destroy is deprecated on Mac OS
    sem_close(lock);
    sem_unlink("/mysem");

    curr_time = time(NULL);
    printf("main: current time %s", asctime(gmtime(&curr_time)));

    return 0;
}