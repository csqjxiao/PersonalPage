#include <stdio.h>
#include "mythreads.h"
#include <stdlib.h>
#include <pthread.h>

int max;
volatile int counter = 0; // shared global variable

enum bool {FALSE,TRUE};

volatile enum bool flag[2] = {FALSE, FALSE};
volatile int victim = 0;

void *
mythread(void *arg)
{
  	int id = * (int*)arg ;

    int i; // stack (private per thread) 
    printf("thread %d: begin [addr of i: %p]\n", id, &i);
    for (i = 0; i < max; i++) {
        flag[id] = TRUE;   // I’m interested
        __sync_synchronize(); // This builtin issues a full memory barrier.
        victim = id;        // You go first
        while (flag[1-id] && victim == id) ;
        __sync_synchronize(); // This builtin issues a full memory barrier.

    	counter = counter + 1; // shared: only one

        __sync_synchronize(); // This builtin issues a full memory barrier.
    	flag[id] = FALSE;	// I’m not interested
        //    	__asm__ __volatile__("":::"memory"); // compiler-specific barrier
    }
    printf("thread %d: done\n", id);
    return NULL;
}
                                                                             
int
main(int argc, char *argv[])
{                    
    if (argc != 2) {
	fprintf(stderr, "usage: main-first <loopcount>\n");
	exit(1);
    }
    max = atoi(argv[1]);

    pthread_t p[2];
    int id[2] = {0, 1};

    time_t curr_time = time(NULL);
    printf("main: current time %s", asctime(gmtime(&curr_time)));
    printf("main: begin [counter = %d] [address of counter: %x] \n",
    		counter, (unsigned int) &counter);
    Pthread_create(&p[0], NULL, mythread, &id[0]);
    Pthread_create(&p[1], NULL, mythread, &id[1]);
    // join waits for the threads to finish
    Pthread_join(p[0], NULL);
    Pthread_join(p[1], NULL);
    printf("main: done\n [counter: %d]\n [should: %d]\n", 
	   counter, max*2);

    curr_time = time(NULL);
    printf("main: current time %s", asctime(gmtime(&curr_time)));
    return 0;
}

