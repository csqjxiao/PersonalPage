#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#include <stdio.h>

/*
This program provides a possible solution for producer-consumer problem using mutex and semaphore.
I have used 5 producers and 5 consumers to demonstrate the solution. You can always play with these values.
*/

#define MAX_ITEMS 10 // Maximum items a producer can produce or a consumer can consume
#define BUFFER_SIZE 5 // Size of the buffer
int in = 0;
int out = 0;
int buffer[BUFFER_SIZE];

sem_t * empty;
sem_t * full;
pthread_mutex_t mutex;

void *producer(void *pno)
{   
    int item;
    for(int i = 0; i < MAX_ITEMS; i++) {
        item = rand(); // Produce an random item
        pthread_mutex_lock(&mutex);
        sem_wait(empty);
        buffer[in] = item;
        printf("Producer %d: Insert Item %d at %d\n", *((int *)pno),buffer[in],in);
        in = (in+1)%BUFFER_SIZE;
        sem_post(full);
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

void *consumer(void *cno)
{   
    int item;
    for(int i = 0; i < MAX_ITEMS; i++) {
        pthread_mutex_lock(&mutex);
        sem_wait(full);
        item = buffer[out];
        printf("Consumer %d: Remove Item %d from %d\n",*((int *)cno),item, out);
        out = (out+1)%BUFFER_SIZE;
        sem_post(empty);
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

int main()
{   
    pthread_t pro[5],con[5];
    //sem_init(&empty,0,BufferSize);
    //sem_init(&full,0,0);// sem_init is deprecated on Mac OS
    empty = sem_open("/mysem_empty", O_CREAT, S_IRUSR | S_IWUSR, BUFFER_SIZE); 
    full = sem_open("/mysem_full", O_CREAT, S_IRUSR | S_IWUSR, 0);
    pthread_mutex_init(&mutex, NULL);

    int a[5] = {1,2,3,4,5}; //Just used for numbering the producer and consumer

    for(int i = 0; i < 5; i++) {
        pthread_create(&pro[i], NULL, (void *)producer, (void *)&a[i]);
    }
    for(int i = 0; i < 5; i++) {
        pthread_create(&con[i], NULL, (void *)consumer, (void *)&a[i]);
    }

    for(int i = 0; i < 5; i++) {
        pthread_join(pro[i], NULL);
    }
    for(int i = 0; i < 5; i++) {
        pthread_join(con[i], NULL);
    }

    pthread_mutex_destroy(&mutex);
    //sem_destroy(&empty); // deprecated
    //sem_destroy(&full); // deprecated
    sem_close(empty);
    sem_close(full);

    return 0;   
}