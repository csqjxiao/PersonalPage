#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

typedef struct {
    int num_loops;
    int thread_id;
} arg_t;

sem_t * forks[5];
char sem_name[5][20];

int left(int p)  {
    return p;
}

int right(int p) {
    return (p + 1) % 5;
}

void get_forks(int p) {
    printf("P%d waits for left fork\n", p);
    sem_wait(forks[left(p)]);
    printf("P%d waits for right fork\n", p);
    sem_wait(forks[right(p)]);
}

void put_forks(int p) {
    sem_post(forks[left(p)]);
    sem_post(forks[right(p)]);
}

void think(int p) {
    printf("P%d thinks\n", p);
    return;
}

void eat(int p) {
    printf("P%d thinks\n", p);
    return;
}

void *philosopher(void *arg) {
    arg_t *args = (arg_t *) arg;
    int p = args->thread_id;
    for (int i = 0; i < args->num_loops; i++) {
        think(p);
        get_forks(p);
        eat(p);
        put_forks(p);
    }
    return NULL;
}

static void myHandler(int dummy) {
    for (int i = 0; i < 5; i++) {
        if(forks[i] != NULL) sem_close(forks[i]);
        sem_unlink(sem_name[i]);  // unlink prevents the semaphore existing forever        
    }
    exit(-1);
}
                                                                             
int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "usage: dining_philosophers_deadlock <num_loops>\n");
        exit(1);
    }
    
    for (int i = 0; i < 5; i++) {
        sprintf(sem_name[i], "/mysem_dplock/%d", i);
        sem_unlink(sem_name[i]);  // unlink prevents the semaphore existing forever
	    forks[i] = sem_open(sem_name[i], O_CREAT, S_IRUSR | S_IWUSR, 1);
        // forks[i] = malloc(sizeof(sem_t));
        // sem_init(forks[i], 0, 1);
    }

    signal(SIGQUIT, myHandler);
    signal(SIGINT, myHandler);

    printf("dining: started\n");

    pthread_t p[5];
    arg_t a[5];
    for (int i = 0; i < 5; i++) {
        a[i].num_loops = atoi(argv[1]);
        a[i].thread_id = i;
        pthread_create(&p[i], NULL, philosopher, &a[i]);
    }

    for (int i = 0; i < 5; i++) 
	    pthread_join(p[i], NULL); 

    printf("dining: finished\n");

    for (int i = 0; i < 5; i++) {
        if(forks[i] != NULL) sem_close(forks[i]);
        sem_unlink(sem_name[i]);  // unlink prevents the semaphore existing forever
    }

    return 0;
}