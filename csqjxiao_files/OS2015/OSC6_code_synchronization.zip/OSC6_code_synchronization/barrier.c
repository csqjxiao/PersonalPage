#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define N (16) 
#define M (16)
#define T (1)

double data[N*T][M];

pthread_mutex_t m;
pthread_cond_t cv;

void *calc(void *ptr);

int main() {
    printf("main thread starts\n");
    for(int x = 0; x < N*T; x++)
    	for (int y = 0; y < M; y++)
    		data[x][y] = 0;

    pthread_mutex_init(&m, NULL);
    pthread_cond_init(&cv, NULL);
    pthread_t ids[N]; 
    int tids[N];
    int i;
    printf("main thread creates children threads 0~%d, and each child thread is responsible for %d rows of data.\n", N-1, T);
    for(i = 0; i < N; i++) {
       tids[i] = i;
       pthread_create(&ids[i], NULL, calc, (void *) &(tids[i]));
    }
    for(i = 0; i < N; i++) 
       pthread_join(ids[i], NULL);
    printf("main thread finishes with the following data matrix.\n");

    for(int x = 0; x < N*T; x++) {
      printf("[");
      for (int y = 0; y < M; y++) {
    	  printf("%.1f\t", data[x][y]);
      }
      printf("]\n");
    }
}

int remain = N;
void *calc(void *ptr) {
  int tid = *((int *)ptr);
  // Thread 0 will work on rows 0..15, 
  // thread 1 on rows 16..31
  int x, y, start = T * tid;
  int end = start + T;
  for(x = start; x < end; x++) 
    for (y = 0; y < M; y++)
    { /* do calc #1 */ 
       data[x][y]++;
    }
  printf("child thread %d finishes first calculation\n", tid);

  pthread_mutex_lock(&m);
  remain--; 
  if (remain ==0) {
     printf("****** child thread %d broadcasts condition ******\n", tid);
     pthread_cond_broadcast(&cv);
  } else {
     while(remain != 0) pthread_cond_wait(&cv, &m); 
  }
  pthread_mutex_unlock(&m);

  printf("child thread %d starts second calculation\n", tid);
  // Threads do second calculation
  // Thread 0 will work on rows 0..15, 
  // thread 1 on rows 16..31
  for(x = start; x < end; x++) 
    for (y = 0; y < M; y++)
    { /* do calc #1 */ 
       data[x][y]++;
    }
}
