#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

//#include <assert.h>
//#include <sched.h>

#include <semaphore.h>

typedef struct _rwlock_t {
    sem_t * writelock;
    sem_t * lock;
    int readers;
    sem_t * wflock;
} rwlock_t;

void rwlock_init(rwlock_t * rw) {
    rw->readers = 0;
    rw->lock = sem_open("/mysem_lock", O_CREAT, S_IRUSR | S_IWUSR, 1); 
    rw->writelock = sem_open("/mysem_writelock", O_CREAT, S_IRUSR | S_IWUSR, 1);
    rw->wflock = sem_open("/mysem_wflock", O_CREAT, S_IRUSR | S_IWUSR, 1);
}

void rwlock_acquire_readlock(rwlock_t * rw) {
    sem_wait(rw->wflock);
    sem_post(rw->wflock);
    sem_wait(rw->lock);
    rw->readers++;
    if (rw->readers == 1)
	    sem_wait(rw->writelock);
    sem_post(rw->lock);
}

void rwlock_release_readlock(rwlock_t * rw) {
    sem_wait(rw->lock);
    rw->readers--;
    if (rw->readers == 0)
	    sem_post(rw->writelock);
    sem_post(rw->lock);
}

void rwlock_acquire_writelock(rwlock_t *rw) {
    sem_wait(rw->wflock);
    sem_wait(rw->writelock);
}

void rwlock_release_writelock(rwlock_t *rw) {
    sem_post(rw->writelock);
    sem_post(rw->wflock);
}

int read_loops;
int write_loops;
int counter = 0;

rwlock_t mutex;

void *reader(void *arg) {
    int id = * (int *) arg;
    int local = 0;
    for (int i = 0; i < read_loops; i++) {
        rwlock_acquire_readlock(&mutex);
        local = counter;
        printf("R%d: read %d\n", id, local);
        rwlock_release_readlock(&mutex);
    }
    printf("R%d: done %d\n", id, local);
    return NULL;
}

void *writer(void *arg) {
    int id = * (int *) arg;
    int local = 0;
    for (int i = 0; i < write_loops; i++) {
        rwlock_acquire_writelock(&mutex);
        local = ++counter;
        printf("W%d: write %d\n", id, local);
        rwlock_release_writelock(&mutex);
    }
    printf("W%d: done %d\n", id, local);
    return NULL;
}

#define NUM_OF_READERS 5
#define NUM_OF_WRITERS 2

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "usage: semaphore_reader_writer readloops writeloops\n");
        exit(1);
    }

    pthread_t rd[NUM_OF_READERS], wr[NUM_OF_WRITERS];
    int rd_id[NUM_OF_READERS], wr_id[NUM_OF_WRITERS];

    read_loops = atoi(argv[1]);
    write_loops = atoi(argv[2]);
    
    rwlock_init(&mutex); 
    for(int i=0; i<NUM_OF_READERS; i++) {
        rd_id[i] = i+1;
        pthread_create(&rd[i], NULL, reader, &rd_id[i]);
    }    
    for(int i=0; i<NUM_OF_WRITERS; i++) {
        wr_id[i] = i+1;
        pthread_create(&wr[i], NULL, writer, &wr_id[i]);
    }
    for(int i=0; i<NUM_OF_READERS; i++)
        pthread_join(rd[i], NULL);
    for(int i=0; i<NUM_OF_WRITERS; i++)
        pthread_join(wr[i], NULL);
    printf("all done\n");
    return 0;
}